package app.dataProcess;

public class Company {
    public Metadata __metadata;
    public String TARS_ROV_NEV;
    public String TARS_HOSZ_NEV;
    public String CIM_EGYBEN;
    public String TARS_TIPUS_MEGNEV;
    public int TARS_TIPUS_KOD;
    public String ADOSZAM;
    public String GAZD_FORM;
    public int GAZD_FORM_KOD;
    public String CEGALL;
    public int CEGALL_KOD;
    public String NEMGAZD_AG_MEGNEV;
    public String NEMGAZD_AG_KOD;
    public String NEMGAZD_AGAZAT_MEGNEV;
    public int NEMGAZD_AGAZAT_KOD;
    public String NEMGAZD_SZAKAGAZAT_MEGNEV;
    public int NEMGAZD_SZAKAGAZAT_KOD;
    public long JEGYZ_TOKE_ERT_HUF;
    public String ORSZAG;
    public String ORSZAG_KOD;
    public String REGIO;
    public int REGIO_KOD;
    public String MEGYE;
    public int MEGYE_KOD;
    public String TELEPULES;
    public int TELEPULES_KOD;
    public int ASZ_EVE;
    public Coordinate coordinate;

}
