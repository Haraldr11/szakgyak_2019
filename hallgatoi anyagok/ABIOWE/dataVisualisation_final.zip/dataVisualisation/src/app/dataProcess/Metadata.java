package app.dataProcess;

public class Metadata {
    public String uri;
    public String type;
}
